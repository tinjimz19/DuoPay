"""
Aplica sobre C:\\DuoPay los cambios de PEDIDOS: foto y conversión en venta.

Cada reemplazo comprueba que su ancla aparezca EXACTAMENTE una vez y, si
no, aborta sin escribir nada. Un parche que aplica la mitad es peor que
uno que no aplica: deja el archivo en un estado que nadie escribió.
"""

import pathlib
import sys

RAIZ = pathlib.Path(sys.argv[1])


def editar(rel, pares):
    p = RAIZ / rel
    s = p.read_text(encoding="utf8")
    for a, b in pares:
        n = s.count(a)
        if n != 1:
            print(f"ABORTA {rel}: el ancla aparece {n} veces:\n{a[:120]}")
            sys.exit(1)
        s = s.replace(a, b, 1)
    p.write_text(s, encoding="utf8")
    print("ok", rel)


# ============================================================ 1. los tipos
# `types/database.types.ts` se sincroniza al núcleo de la app móvil, así
# que esto le llega a las dos aplicaciones.

editar(
    "types/database.types.ts",
    [
        # --- preorders: Row
        (
            """          status: PreorderStatus;
          notes: string | null;
          created_at: string;
          deleted_at: string | null;
        };
        Insert: {""",
            """          status: PreorderStatus;
          notes: string | null;
          created_at: string;
          deleted_at: string | null;
          /** Ruta dentro del depósito `pedidos`, no una dirección web. */
          image_path: string | null;
          /** Lleno = este pedido ya se convirtió en esa venta. */
          sale_id: string | null;
        };
        Insert: {""",
        ),
        # --- preorders: Insert
        (
            """          status?: PreorderStatus;
          notes?: string | null;
          created_at?: string;
          deleted_at?: string | null;
        };
        Update: {""",
            """          status?: PreorderStatus;
          notes?: string | null;
          created_at?: string;
          deleted_at?: string | null;
          image_path?: string | null;
          sale_id?: string | null;
        };
        Update: {""",
        ),
        # --- preorders: Update
        (
            """          status?: PreorderStatus;
          notes?: string | null;
          created_at?: string;
          deleted_at?: string | null;
        };
        Relationships: [""",
            """          status?: PreorderStatus;
          notes?: string | null;
          created_at?: string;
          deleted_at?: string | null;
          image_path?: string | null;
          sale_id?: string | null;
        };
        Relationships: [""",
        ),
        # --- la función de la base
        (
            """    Functions: {
      store_emails: {""",
            """    Functions: {
      /**
       * Convierte un pedido en venta: crea la venta y marca el pedido,
       * las dos cosas en una sola transacción. Vive en la base porque la
       * app móvil habla con ella directamente y no debería repetir la
       * lógica —y porque hechas por separado, si la segunda falla, el
       * pedido se puede convertir dos veces y el cliente queda debiendo
       * el doble—.
       */
      convertir_pedido_en_venta: {
        Args: {
          p_pedido: string;
          p_cliente: string;
          p_descripcion: string;
          p_total: number;
          p_cuotas: number;
          p_nota?: string | null;
        };
        /** El id de la venta recién creada. */
        Returns: string;
      };
      store_emails: {""",
        ),
    ],
)


# ==================================================== 2. cliente con nombre
# El diálogo de cliente nuevo se abre desde la conversión con el nombre
# suelto del pedido ya escrito. Sin esto habría que teclearlo otra vez.

editar(
    "components/clients/client-form-dialog.tsx",
    [
        (
            """export function ClientFormDialog({
  client,
  compact = false,
  triggerClassName,
  onCreated,
}: {
  client?: ClientFormData | null;
  compact?: boolean;
  triggerClassName?: string;
  onCreated?: (client: { id: string; name: string }) => void;
}) {""",
            """export function ClientFormDialog({
  client,
  compact = false,
  defaultName = "",
  triggerClassName,
  onCreated,
}: {
  client?: ClientFormData | null;
  compact?: boolean;
  /**
   * Nombre con el que abrir el formulario.
   *
   * Lo usa la conversión de un pedido: el encargo traía "la señora del
   * kiosco" escrito suelto y ese nombre aparece ya puesto en vez de
   * obligar a teclearlo de nuevo delante del cliente.
   */
  defaultName?: string;
  triggerClassName?: string;
  onCreated?: (client: { id: string; name: string }) => void;
}) {""",
        ),
        (
            """      name: client?.name ?? "",""",
            """      name: client?.name ?? defaultName ?? "",""",
        ),
    ],
)


# ================================================== 3. acciones de pedidos

editar(
    "actions/preorder-actions.ts",
    [
        # La foto se guarda con su propia acción (ver el comentario de abajo).
        (
            """export async function updatePreorderStatus(id: string, status: PreorderStatus) {""",
            '''/**
 * Guarda (o quita) la ruta de la foto de un pedido.
 *
 * Va separada del alta a propósito: la ruta de la foto lleva dentro el id
 * del pedido, y ese id no existe hasta que la fila está creada. Así que
 * el orden es guardar el pedido, subir el archivo, y apuntar aquí dónde
 * quedó. El archivo lo sube el navegador directo al depósito —no pasa por
 * este servidor— porque una foto de varios megas ida y vuelta por una
 * acción de servidor es lento y además no hace falta: las reglas del
 * depósito ya impiden escribir en la carpeta de otra tienda.
 */
export async function setPreorderImage(id: string, imagePath: string | null) {
  const supabase = createClient();

  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser();

  if (authError || !user) {
    return { success: false, error: "No autorizado" };
  }

  // Que la ruta sea de SU carpeta. La política del depósito ya lo impide
  // al subir, pero esta columna se puede escribir sin subir nada, y una
  // ruta ajena aquí serviría para espiar la foto de otra tienda.
  if (imagePath && !imagePath.startsWith(`${user.id}/`)) {
    return { success: false, error: "Ruta de foto inválida" };
  }

  const { error } = await supabase
    .from("preorders")
    .update({ image_path: imagePath })
    .eq("id", id)
    .eq("user_id", user.id);

  if (error) {
    return { success: false, error: error.message };
  }

  revalidatePath("/pedidos");
  return { success: true };
}

export async function updatePreorderStatus(id: string, status: PreorderStatus) {''',
        ),
    ],
)


# ============================================ 4. la página, con las firmas

editar(
    "app/(dashboard)/pedidos/page.tsx",
    [
        (
            '        "id, product_name, category, client_id, client_name_raw, quantity, estimated_price, status, notes, created_at, clients(name)"',
            '        "id, product_name, category, client_id, client_name_raw, quantity, estimated_price, status, notes, created_at, image_path, sale_id, clients(name)"',
        ),
        (
            """  const mapped: PreorderCardData[] = (preorders ?? []).map((p) => ({""",
            """  /*
    Las direcciones de las fotos se firman aquí, en el servidor.

    El depósito es privado: no hay una dirección fija que sirva siempre.
    Se pide una firmada con vencimiento, y se piden TODAS DE UNA —con
    `createSignedUrls`, en plural— en vez de una por tarjeta: una lista de
    cuarenta pedidos serían cuarenta viajes al servidor, uno detrás de
    otro, y la página tardaría un segundo largo en aparecer.

    Una hora de validez es de sobra para mirar una lista, y es tiempo
    suficiente para que el enlace no sobreviva a la sesión.
  */
  const rutas = (preorders ?? [])
    .map((p) => p.image_path)
    .filter((r): r is string => Boolean(r));

  const firmadas = new Map<string, string>();
  if (rutas.length > 0) {
    const { data } = await supabase.storage
      .from("pedidos")
      .createSignedUrls(Array.from(new Set(rutas)), 60 * 60);
    for (const item of data ?? []) {
      if (item.signedUrl && item.path) firmadas.set(item.path, item.signedUrl);
    }
  }

  const mapped: PreorderCardData[] = (preorders ?? []).map((p) => ({""",
        ),
        (
            """    notes: p.notes,
    created_at: p.created_at,
  }));""",
            """    notes: p.notes,
    created_at: p.created_at,
    image_path: p.image_path,
    image_url: p.image_path ? firmadas.get(p.image_path) ?? null : null,
    sale_id: p.sale_id,
  }));""",
        ),
    ],
)

# ============================================= 5. convertir pedido en venta

CONVERTIR = pathlib.Path(__file__).with_name("convert-action.ts").read_text(encoding="utf8")

p = RAIZ / "actions/preorder-actions.ts"
s = p.read_text(encoding="utf8")
if "convertPreorderToSale" not in s:
    p.write_text(s.rstrip() + "\n\n\n" + CONVERTIR, encoding="utf8")
    print("ok  + convertPreorderToSale")
else:
    print("ya estaba convertPreorderToSale")

print("\nTodo aplicado.")
