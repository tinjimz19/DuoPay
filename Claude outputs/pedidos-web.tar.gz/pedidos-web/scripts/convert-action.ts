const convertPreorderSchema = z.object({
  preorderId: z.string().uuid(),
  clientId: z.string().uuid("Selecciona un cliente"),
  itemDescription: z
    .string()
    .min(3, "Describe la mercancía")
    .max(300, "Descripción muy larga"),
  totalAmount: z.coerce
    .number({ message: "Monto inválido" })
    .positive("El monto debe ser mayor a 0"),
  installmentsCount: z.coerce
    .number({ message: "Cuotas inválidas" })
    .int("Las cuotas deben ser un número entero")
    .min(1, "Al menos 1 cuota")
    .max(36, "Máximo 36 cuotas"),
  notes: z.string().max(500).optional().nullable(),
});

export type ConvertPreorderInput = z.infer<typeof convertPreorderSchema>;

/**
 * Convierte un pedido en una venta.
 *
 * LAS DOS ESCRITURAS VAN JUNTAS, Y POR ESO ESTO LLAMA A LA BASE
 *
 * Hay que crear la venta Y marcar el pedido. Hechas por separado, si la
 * segunda falla queda una venta creada y un pedido que todavía enseña el
 * botón de convertir: el siguiente clic crea una SEGUNDA venta y el
 * cliente aparece debiendo el doble. La función `convertir_pedido_en_venta`
 * hace las dos dentro de una transacción, con la fila del pedido
 * bloqueada, así que ni dos clics seguidos ni el teléfono y la
 * computadora a la vez pueden duplicarla.
 *
 * Eso mismo es lo que hace que la app móvil no tenga que repetir nada:
 * llama a la misma función.
 *
 * Aquí arriba solo queda lo que la base no puede hacer: validar la
 * entrada con mensajes en castellano y refrescar las páginas que ahora
 * enseñan algo distinto.
 */
export async function convertPreorderToSale(input: ConvertPreorderInput) {
  const parsed = convertPreorderSchema.parse(input);
  const supabase = createClient();

  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser();

  if (authError || !user) {
    return { success: false, error: "No autorizado" };
  }

  const { data, error } = await supabase.rpc("convertir_pedido_en_venta", {
    p_pedido: parsed.preorderId,
    p_cliente: parsed.clientId,
    p_descripcion: parsed.itemDescription.trim(),
    p_total: parsed.totalAmount,
    p_cuotas: parsed.installmentsCount,
    p_nota: parsed.notes?.trim() || null,
  });

  if (error) {
    // Los mensajes de la función ya vienen en castellano y pensados para
    // el dueño de la tienda ("Este pedido ya se convirtió en venta"). Se
    // pasan tal cual; solo se traduce lo que viene de Postgres en crudo.
    return { success: false, error: mensajeDeBase(error.message) };
  }

  revalidatePath("/");
  revalidatePath("/pedidos");
  revalidatePath("/ventas");
  revalidatePath("/clientes");
  revalidatePath(`/clientes/${parsed.clientId}`);

  return { success: true, saleId: data as string };
}

function mensajeDeBase(bruto: string): string {
  const texto = bruto.toLowerCase();
  if (texto.includes("jwt") || texto.includes("expired")) {
    return "Se venció la sesión. Vuelve a entrar.";
  }
  if (texto.includes("could not find the function")) {
    // El caso real: la migración de pedidos todavía no se corrió.
    return "Falta correr la migración de pedidos en la base de datos.";
  }
  if (texto.includes("permission denied") || texto.includes("row-level security")) {
    return "No tienes permiso para esto.";
  }
  if (texto.includes("fetch") || texto.includes("network")) {
    return "Sin conexión. Intenta de nuevo.";
  }
  return bruto;
}
